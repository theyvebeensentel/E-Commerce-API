from django.shortcuts import get_object_or_404
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .models import User, Order, CartItem
from .serializers import UserSerializer, OrderSerializer, CartItemSerializer
from django.http import JsonResponse

def home(request):
    return JsonResponse({
        "message": "Welcome to the E-Commerce API!",
        "api_docs": "/swagger/"
    })


class OrderView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, order_id=None):
        user_id = request.META.get('HTTP_X_USER_ID')
        user = get_object_or_404(User, id=user_id)

        if order_id:
            order = get_object_or_404(Order, id=order_id, user=user)
            return Response(OrderSerializer(order).data)

        orders = Order.objects.raw('SELECT * FROM core_order WHERE user_id = %s', [user.id])
        return Response([OrderSerializer(order).data for order in orders])

    def put(self, request):
        order_data = request.data
        order = get_object_or_404(Order, id=order_data['id'])
        serializer = OrderSerializer(order, data=order_data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request):
        order_id = request.data.get('id')
        order = get_object_or_404(Order, id=order_id)
        order.delete()
        return Response({'message': 'Order deleted successfully'}, status=status.HTTP_204_NO_CONTENT)


class CartItemView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user_id = request.META.get('HTTP_X_USER_ID')
        user = get_object_or_404(User, id=user_id)
        pending_order = get_object_or_404(Order, user=user, status=Order.PENDING)
        cart_items = CartItem.objects.filter(order=pending_order)
        return Response(CartItemSerializer(cart_items, many=True).data)

    def post(self, request):
        data = request.data
        serializer = CartItemSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def put(self, request):
        cart_item_id = request.data['id']
        cart_item = get_object_or_404(CartItem, id=cart_item_id)
        serializer = CartItemSerializer(cart_item, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request):
        cart_item_id = request.data['id']
        cart_item = get_object_or_404(CartItem, id=cart_item_id)
        cart_item.delete()
        return Response({'message': 'Cart item deleted successfully'}, status=status.HTTP_204_NO_CONTENT)


class CheckoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user_id = request.META.get('HTTP_X_USER_ID')
        user = get_object_or_404(User, id=user_id)
        pending_order = Order.objects.filter(user=user, status=Order.PENDING).first()

        if not pending_order:
            return Response({'error': 'No pending order'}, status=status.HTTP_400_BAD_REQUEST)

        if not pending_order.cart_items.exists():
            return Response({'error': 'No items in cart'}, status=status.HTTP_400_BAD_REQUEST)

        pending_order.status = Order.PROCESSED
        pending_order.save()
        return Response(OrderSerializer(pending_order).data)
