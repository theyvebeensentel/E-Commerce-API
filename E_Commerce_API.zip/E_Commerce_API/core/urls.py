from django.urls import path
from .views import OrderView, CartItemView, CheckoutView

urlpatterns = [
    path('orders', OrderView.as_view()),
    path('orders/<uuid:order_id>', OrderView.as_view()),
    path('cart-items', CartItemView.as_view()),
    path('checkout', CheckoutView.as_view()),
]
